from kivy.app import App
from kivy.uix.screenmanager import ScreenManager, Screen
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from kivy.uix.label import Label
from kivy.uix.filechooser import FileChooserIconView
import json
import os

# صفحه انتخاب عکس
class PhotoScreen(Screen):
    def __init__(self, part_name, **kwargs):
        super().__init__(**kwargs)
        self.part_name = part_name
        layout = BoxLayout(orientation="vertical", padding=10, spacing=10)
        layout.add_widget(Label(text=f"📷 لطفاً عکس {self.part_name} را انتخاب کنید", size_hint_y=None, height=40))
        self.fc = FileChooserIconView(size_hint=(1, 0.8))
        layout.add_widget(self.fc)
        btn = Button(text="مرحله بعد", size_hint_y=None, height=44)
        btn.bind(on_press=self.save_photo)
        layout.add_widget(btn)
        self.add_widget(layout)

    def save_photo(self, *args):
        if self.fc.selection:
            app = App.get_running_app()
            # copy the selected path string (we do not copy the file to keep it simple for Colab)
            app.photos[self.part_name] = self.fc.selection[0]
            app.next_screen()
        else:
            # no selection, do nothing or show warning
            pass

# صفحه نتیجه
class ResultScreen(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        layout = BoxLayout(orientation="vertical", padding=10, spacing=10)
        self.label = Label(text="⏳ تحلیل در حال انجام...")
        layout.add_widget(self.label)
        self.add_widget(layout)

    def on_enter(self, *args):
        app = App.get_running_app()
        plan = app.analyze_images(app.photos)
        # نمایش خروجی به صورت متن ساده
        self.label.text = f"✅ برنامه پیشنهادی:\\n\\n{plan}"

# مدیریت صفحات
class MyScreenManager(ScreenManager):
    pass

class FitnessApp(App):
    def build(self):
        self.photos = {}
        # لیست نواحی که از کاربر عکس می‌خواهیم
        self.parts = ["گردن", "شانه_چپ", "شانه_راست", "بازو_چپ", "بازو_راست", "سینه", "شکم", "پشت", "ران_چپ", "ران_راست"]
        self.sm = MyScreenManager()
        self.idx = 0
        self.next_screen()
        return self.sm

    def next_screen(self):
        if self.idx < len(self.parts):
            part = self.parts[self.idx]
            ps = PhotoScreen(name=f"screen{self.idx}", part_name=part)
            # remove previous screen with same name if exists
            if self.sm.has_screen(ps.name):
                self.sm.remove_widget(self.sm.get_screen(ps.name))
            self.sm.add_widget(ps)
            self.sm.current = ps.name
            self.idx += 1
        else:
            rs = ResultScreen(name="result")
            if self.sm.has_screen("result"):
                self.sm.remove_widget(self.sm.get_screen("result"))
            self.sm.add_widget(rs)
            self.sm.current = "result"

    def analyze_images(self, photos):
        # ⚠️ اینجا فعلاً تحلیل واقعی انجام نمی‌دهد.
        # هدف: فایل meta.json را بسازد و یک برنامه نمونه برگرداند.
        os.makedirs("user_output", exist_ok=True)
        meta = {
            "photos": photos,
            "note": "این خروجی نمونه است و تحلیل تصویر واقعی در این نسخه اجرا نمی‌شود."
        }
        with open("user_output/meta.json", "w", encoding="utf-8") as f:
            import json
            json.dump(meta, f, ensure_ascii=False, indent=2)

        # یک برنامه غذایی و تمرینی نمونه برمی‌گردانیم
        return (
            "🔹 رژیم غذایی: مصرف پروتئین بالا (سینه مرغ، تخم‌مرغ، حبوبات)، سبزیجات زیاد، کاهش قند ساده.\n"
            "🔹 ورزش: 4 روز در هفته - 2 روز تمرین مقاومتی (تمرکز روی بالا تنه و پایین تنه)، 2 روز کاردیو سبک.\n"
            "🔹 نکته: برای تحلیل دقیق‌تر تصاویر، در نسخه بعدی تصاویر به سرور ارسال و مدل ML اجرا خواهد شد."
        )

if __name__ == "__main__":
    FitnessApp().run()
