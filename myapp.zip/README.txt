راهنما:
این پوشه شامل یک اپ نمونه Kivy است که می‌توانید در Google Colab آپلود کرده و با Buildozer بیلد کنید.
محتویات:
- main.py : کد اپ
- buildozer.spec : فایل پیکربندی بیلد

مراحل سریع در Colab:
1) آپلود myapp.zip با استفاده از فایل نوت‌بوک
2) unzip myapp.zip و cd به پوشه استخراج‌شده
3) اجرا: buildozer -v android debug
4) بعد از پایان در bin/ فایل APK قرار می‌گیرد
